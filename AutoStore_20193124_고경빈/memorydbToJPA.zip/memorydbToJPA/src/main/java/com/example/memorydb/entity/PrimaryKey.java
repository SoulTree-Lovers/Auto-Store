package com.example.memorydb.entity;

public interface PrimaryKey {
    void setId(Long id);

    Long getId();
}
