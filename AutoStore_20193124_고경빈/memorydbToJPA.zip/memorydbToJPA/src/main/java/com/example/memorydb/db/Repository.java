package com.example.demo.db;

public interface Repository<T, ID> {
}
